package com.microservice.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
